﻿import csv
import re
import subprocess

# Bước 1: Đọc đường dẫn từ file CSV
def get_paths_from_csv(csv_file):
    csv_paths = set()
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader)
        for row in reader:
            for cell in row:
                if isinstance(cell, str) and "\\" in cell:
                    csv_paths.add(cell.strip())
    return csv_paths

# Bước 2: Trích xuất đường dẫn từ đầu ra exe (dạng text hoặc file .txt)
def get_paths_from_text(text_file):
    exe_paths = set()
    with open(text_file, 'r', encoding='utf-8') as f:
        content = f.read()
        # Regex tìm tất cả đường dẫn kiểu Windows
        matches = re.findall(r'[A-Z]:\\(?:[^\\\n\r]+\\)*[^\\\s\n\r]+', content)
        for match in matches:
            exe_paths.add(match.strip())
    return exe_paths

# Bước 3: Tìm giao nhau
def get_common_paths(csv_file, text_file):
    csv_paths = get_paths_from_csv(csv_file)
    exe_paths = get_paths_from_text(text_file)
    common = csv_paths & exe_paths
    return common

with open("dll_detect_output.txt", "w", encoding="utf-8") as output_file:
    subprocess.run(
        [r"C:\Users\student\Downloads\Project-DLL-Hijack\dll_hijack_detect_x64.exe", "/unsigned"],
        stdout=output_file,
        stderr=subprocess.STDOUT,  # Ghi cả lỗi (nếu có) vào file
        shell=True
    )

# Ví dụ sử dụng
csv_file_path = r'C:\Users\student\Downloads\Project-DLL-Hijack\query_1.csv'
exe_output_path = r'C:\Users\student\Downloads\Project-DLL-Hijack\dll_detect_output.txt'  # Lưu kết quả cmd thành file text trước

common_paths = get_common_paths(csv_file_path, exe_output_path)

# In kết quả
print("⚠️ Đường dẫn có khả năng là mã độc:")
for path in sorted(common_paths):
    print("❌ "+path)
